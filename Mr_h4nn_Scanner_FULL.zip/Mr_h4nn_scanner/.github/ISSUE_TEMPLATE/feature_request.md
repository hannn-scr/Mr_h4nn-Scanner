---
name: Feature Request
about: Suggest a new feature or improvement for Mr_h4nn Scanner
title: "[FEATURE] "
labels: enhancement
assignees: Mr.h4nn
---

## Feature Summary

A clear and concise description of the feature you'd like to see.

---

## Problem / Motivation

Is this feature solving a problem? Describe it.
e.g. "I'm always having to manually save output because there's no export option..."

---

## Proposed Solution

Describe what you'd like to happen. Be as specific as possible.

---

## Alternatives Considered

Have you considered any alternative solutions or workarounds? Describe them.

---

## Which module would this affect?

- [ ] `Mr_h4nn Scanner.py` (main menu / router)
- [ ] `wpvuln.py` (WordPress scanner)
- [ ] `websqli.py` (SQLi scanner)
- [ ] `webshake.py` (web crawler)
- [ ] `webanalyst.py` (web analyzer)
- [ ] `Mr_h4nn Scannerconf.py` (config)
- [ ] `Mr_h4nn Scannerup.py` (updater)
- [ ] `Mr_h4nn Scanner.sh` (launcher)
- [ ] `install.sh` (installer)
- [ ] New module
- [ ] Other / unsure

---

## Additional Context

Add any other context, mockups, or examples here.
