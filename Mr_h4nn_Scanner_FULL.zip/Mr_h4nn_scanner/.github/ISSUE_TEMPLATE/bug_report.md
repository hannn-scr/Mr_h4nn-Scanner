---
name: Bug Report
about: Report a bug or unexpected behavior in Mr_h4nn Scanner
title: "[BUG] "
labels: bug
assignees: hannn-scr
---

## Bug Description

A clear and concise description of what the bug is.

---

## Steps to Reproduce

1. Run `bash Mr_h4nn Scanner.sh`
2. Choose option `[...]`
3. Enter URL `...`
4. See error

---

## Expected Behavior

What did you expect to happen?

---

## Actual Behavior

What actually happened? Paste the full error output below.

```
Paste error output here
```

---

## Environment

| Field | Value |
|-------|-------|
| OS / Platform | e.g. Termux on Android 13 / Ubuntu 22.04 |
| Python version | e.g. Python 3.11.2 |
| Mr_h4nn Scanner version | e.g. 1.0.0 |
| Termux version (if applicable) | e.g. 0.118 |

---

## Additional Context

Add any other context, screenshots, or logs that might help.
